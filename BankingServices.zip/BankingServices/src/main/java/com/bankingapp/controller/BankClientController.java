package com.bankingapp.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.bankingapp.models.Account;
import com.bankingapp.models.AccountDTO;
import com.bankingapp.models.ApplicationUser;
import com.bankingapp.models.Customer;
import com.bankingapp.models.CustomerDto;

@Controller
public class BankClientController {

	@Autowired
	private RestTemplate restTemplate;
//	@Autowired
//	private DiscoveryClient discoveryClient;

	@GetMapping("/")
	public String home() {
		return "home";
	}

	@GetMapping("/createCustomer")
	public String createCustomer() {
		return "CreateCustomer";

	}
	
	@GetMapping("/createAccount")
	public String createAccount() {
		return "CreateAccount";

	}
	
	@GetMapping("/depositAccount")
	public String depositAccount() {
		return "DepositList";

	}
	

	@PostMapping("/userlogin")
	public String userLogin(@RequestParam("username") String username, @RequestParam("password") String password,
			Model model, HttpSession session) {
		System.out.println(username);
		System.out.println(password);
		ApplicationUser user = new ApplicationUser();

		user.setUsername(username);
		user.setPassword(password);
		int status;
		try {

			ResponseEntity<ApplicationUser> res = restTemplate.postForEntity("http://localhost:8090/authservice/auth",
					user, ApplicationUser.class);
			ApplicationUser userObj = (ApplicationUser) res.getBody();
			System.out.println(userObj);
			session.setAttribute("userId", userObj.getUserId());
			status = res.getStatusCodeValue();
			System.out.println(res.getStatusCodeValue());
			return "redirect:/customers";
		} catch (Exception e) {

			status = 400;
			model.addAttribute("message", "UserName and Password invalid" + e);

			return "home";
		}
	}
	
    //All Customer List
	@GetMapping("/customers")
	public String getAllCustomer(HttpSession session) {
		CustomerDto cusdto = restTemplate.getForObject("http://localhost:8084/customerservice/customers",
				CustomerDto.class);
		// model.addAttribute("ProductList",dto.getList());
		session.setAttribute("CustomerList", cusdto.getList());
		return "customerList";
	}

	//All Account List
	@GetMapping("/accounts")
	public String getAllAccount(HttpSession session) {
		AccountDTO dto = new AccountDTO();
		try {
			dto = restTemplate.getForObject("http://localhost:8085/accountservice/accounts", AccountDTO.class);
			// model.addAttribute("ProductList",dto.getList());
			List<Account> list = dto.getList();
			System.out.println(list);
			session.setAttribute("AccountList", list);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return "accountList";
		}
		return "accountList";
	}

//	@GetMapping("/viewCart")
//	public String getCartItems(HttpSession session) {
//		CartDTO dto= new CartDTO();
//		try {
//		dto=restTemplate.getForObject("http://localhost:8084/cartservice/getCartItems",CartDTO.class);
//		
//		List<Cart> list=dto.getList();
//		System.out.println(list);
//		session.setAttribute("cartItems", list);
//		}
//		catch(Exception e) {
//			System.out.println(e.getMessage());
//			return "Cart";
//		}
//		return "Cart";
//	}

//	@PostMapping("/create")
//	public String addCustomer(@RequestParam("username") String username, Model model,HttpSession session) {
//		System.out.println(username);
//		System.out.println(password);
//		ApplicationUser user=new ApplicationUser();
//		Customer cus=new Customer();
//		
//		user.setUsername(username);
//		
//		int status;
//		try {
//			
//		ResponseEntity<ApplicationUser> res=restTemplate.postForEntity("http://localhost:8084/customerservice/create", user, ApplicationUser.class);
//		ApplicationUser userObj=(ApplicationUser) res.getBody();
//		System.out.println(userObj);
//		session.setAttribute("userId", userObj.getUserId());
//		status=res.getStatusCodeValue();
//		System.out.println(res.getStatusCodeValue());
//		return "redirect:/customers";
//		}
//		catch(Exception e)
//		{
//			
//			status=400;
//			model.addAttribute("message","UserName and Password invalid"+e);		
//			
//			return "home";
//		}	
//	}

	
	//Adding Customer
	@PostMapping("create")
	public String addCustomer(@RequestParam("cusId") int cusId, @RequestParam("cusName") String cusName,
			@RequestParam("cusEmail") String cusEmail, @RequestParam("cusMob") long cusMob,
			@RequestParam("cusAadhar") long cusAadhar, @RequestParam("cusPermaAdd") String cusPermaAdd,
			@RequestParam("cusResiAdd") String cusResiAdd, @RequestParam("cusDob") String cusDob, Model model,
			HttpSession session) {
		int userId = 0;
		userId = (int) session.getAttribute("userId");
		if (userId == 0) {
			return "SessionExpired";
		}
		System.out.println(cusId);
		Customer cus = new Customer();
		cus.setCusId(cusId);
		cus.setCusName(cusName);
		cus.setCusEmail(cusEmail);
		cus.setCusMob(cusMob);
		cus.setCusAadhar(cusAadhar);
		cus.setCusPrmaAdd(cusPermaAdd);
		cus.setCusResiAdd(cusResiAdd);
		cus.setCusDob(cusDob);

		int status;
		try {

			ResponseEntity<Customer> res = restTemplate.postForEntity("http://localhost:8084/customerservice/create",
					cus, Customer.class);
			Customer customer = (Customer) res.getBody();
			System.out.println(customer);
//				session.setAttribute("userId", customer.getCusId());
//				status = res.getStatusCodeValue();
			System.out.println(res.getStatusCodeValue());
			return "redirect:/customers";
		} catch (Exception e) {

			status = 400;
			model.addAttribute("message", "UserName and Password invalid" + e);

			return "home";
		}

	}

	
	//Adding Account 
	@PostMapping("createAcc")
	public String addAccount(@RequestParam("accNumber") long accNumber,
			@RequestParam("accBalance") double accBalance,
			@RequestParam("accBranch") String accBranch,
			//@RequestParam("accOpenDate") LocalDate accOpenDate,
			@RequestParam("accType") String accType,
			Model model,
			HttpSession session) {
		int userId = 0;
		userId = (int) session.getAttribute("userId");
		if (userId == 0) {
			return "SessionExpired";
		}
		//System.out.println(cusId);
		Account acc=new Account();
		acc.setAccNumber(accNumber);
		acc.setAccBalance(accBalance);
		acc.setAccBranch(accBranch);
		//acc.setAccOpenDate(accOpenDate);
		acc.setAccType(accType);

		int status;
		try {

			ResponseEntity<Account> res = restTemplate.postForEntity("http://localhost:8085/accountservice/create",
					acc, Account.class);
			Account account = (Account) res.getBody();
			System.out.println(account);
//				session.setAttribute("userId", customer.getCusId());
//				status = res.getStatusCodeValue();
			System.out.println(res.getStatusCodeValue());
			return "redirect:/accounts";
		} catch (Exception e) {

			status = 400;
			model.addAttribute("message", "UserName and Password invalid" + e);

			return "home";
		}

	}

	
	
	// update customer
		@GetMapping("/updatecustomer/{cusId}")
		public String updateCustomer(@PathVariable("cusId") int cusId) {
			//restTemplate.updateCustomer("http://localhost:8084/customerservice/update/"+cusId);
			 return "redirect:/customers";
		}
	
	
	
	// delete customer
	@GetMapping("/deletecustomer/{cusId}")
	public String deleteCustomer(@PathVariable("cusId") int cusId) {
		restTemplate.delete("http://localhost:8084/customerservice/delete/"+cusId);
		 return "redirect:/customers";
	}
	
	  // delete Account
		@GetMapping("/deleteaccount/{accnum}")
		public String deleteAccount(@PathVariable("accnum") long accNum) {
			restTemplate.delete("http://localhost:8085/accountservice/delete/"+accNum);
			return "redirect:/accounts";
		}
		
		//Deposit
		@GetMapping("/deposit")
		public String depositAccount(@RequestParam("accNumber") Long accNum,@RequestParam("amount") double amount) {
			System.out.println(accNum+" "+amount);
			restTemplate.getForObject("http://localhost:8085/accountservice/deposit/"+accNum+"/"+amount,Object.class);
			return "redirect:/accounts";
		}
	
	
	
	
	//Update customer

	
	

//	@PostMapping("/create")
//	public String addCustomer(@PathVariable("customer") int productId,HttpSession session) {
//		int  userId=0;
//		userId=(int) session.getAttribute("userId");
//		if(userId==0) {
//			return "SessionExpired";
//		}
//		List<Product> list=(List<Product>) session.getAttribute("ProductList");
//		for(Product p:list) {
//			if(p.getProductId()==productId) {
//			Cart cart=new Cart();
//			cart.setUserid(userId);
//			cart.setProductId(productId);
//			cart.setProductname(p.getProductName());
//			cart.setProductPrice(p.getProductPrice());
//			cart.setQuantity(1);
//			cart.setSumTotal(p.getProductPrice());
//			ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8084/cartservice/addItem",cart,Object.class);
//			System.out.println(res.getStatusCodeValue());
//			}
//		}
//		return "redirect:/products";
//	}
//	
//	@GetMapping("/products")
//	public String getproducts(HttpSession session) {
//		ProductDTO dto=restTemplate.getForObject("http://localhost:8083/productservice/products",ProductDTO.class);
//		//model.addAttribute("ProductList",dto.getList());
//		session.setAttribute("ProductList", dto.getList());
//		return "productList";
//	}
//	
//	@PostMapping("/addToCart/{productId}")
//	public String addToCart(@PathVariable("productId") int productId,HttpSession session) {
//		int  userId=0;
//		userId=(int) session.getAttribute("userId");
//		if(userId==0) {
//			return "SessionExpired";
//		}
//		List<Product> list=(List<Product>) session.getAttribute("ProductList");
//		for(Product p:list) {
//			if(p.getProductId()==productId) {
//			Cart cart=new Cart();
//			cart.setUserid(userId);
//			cart.setProductId(productId);
//			cart.setProductname(p.getProductName());
//			cart.setProductPrice(p.getProductPrice());
//			cart.setQuantity(1);
//			cart.setSumTotal(p.getProductPrice());
//			ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8084/cartservice/addItem",cart,Object.class);
//			System.out.println(res.getStatusCodeValue());
//			}
//		}
//		return "redirect:/products";
//	}
//	
//	@GetMapping("/viewCart")
//	public String getCartItems(HttpSession session) {
//		CartDTO dto= new CartDTO();
//		try {
//		dto=restTemplate.getForObject("http://localhost:8084/cartservice/getCartItems",CartDTO.class);
//		
//		List<Cart> list=dto.getList();
//		System.out.println(list);
//		session.setAttribute("cartItems", list);
//		}
//		catch(Exception e) {
//			System.out.println(e.getMessage());
//			return "Cart";
//		}
//		return "Cart";
//	}
//	
//	@GetMapping("/deleteFromCart/{id}")
//	public String deleteFromCart(@PathVariable("id") int id) {
//		restTemplate.delete("http://localhost:8084/cartservice/delete/"+id);
//		return"redirect:/viewCart";
//	}
//	
//	@GetMapping("/placeOrder")
//	public String placeOrder(HttpSession session) {
//		List<Cart> cartList=(List<Cart>) session.getAttribute("cartItems");
//		List<OrderItem> items=new ArrayList();
//		int grandTotal=0;
//		for(Cart c:cartList) {
//			OrderItem o=new OrderItem();
//			//o.setOrderId(0);
//			o.setProductid(c.getProductId());
//			o.setProductName(c.getProductname());
//			o.setProductPrice(c.getProductPrice());
//			o.setQuantity(c.getQuantity());
//			o.setSubTotal(c.getSumTotal());
//			grandTotal+=c.getSumTotal();
//			items.add(o);
//		
//		}
//		session.setAttribute("orderItems",items);
//		session.setAttribute("grandTotal",grandTotal);
//		
//		return "PlaceOrder";
//	}
//	
//	@PostMapping("/confirmOrder")
//	public String confirmOrder(@RequestParam("address") String address,@RequestParam("mode") String mode, HttpSession session) {
//		
//		long millis=System.currentTimeMillis();  
//        java.sql.Date date=new java.sql.Date(millis);  
//        if(session.getAttribute("userId")==null) {
//        	return "SessionExpired";
//        }
//		
//		Order order=new Order();
//		order.setDeliveryAddress(address);
//		order.setPaymentMode(mode);
//		order.setOrderAmount((int) session.getAttribute("grandTotal"));
//		order.setUserid((int) session.getAttribute("userId"));
//		order.setOrderItems((List<OrderItem>) session.getAttribute("orderItems"));
//		order.setOrderDate(date);
//		System.out.println(order.getOrderItems());
//		ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8085/orderservice/placeOrder", order, Object.class);
//		System.out.println(res.getStatusCodeValue());
//		restTemplate.delete("http://localhost:8084/cartservice/deleteAll");
//		
//		
//		List<Cart> cartList=null;
//		session.setAttribute("cartItems", cartList);
//		
//		return "Thanks";
//	}

}
